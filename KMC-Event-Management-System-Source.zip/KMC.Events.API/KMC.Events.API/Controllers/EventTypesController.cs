﻿using KMC.Events.API.Data;
using KMC.Events.API.DTOs;
using KMC.Events.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KMC.Events.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class EventTypesController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public EventTypesController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: api/eventtypes
    [HttpGet]
    public async Task<ActionResult<IEnumerable<EventType>>> GetEventTypes()
    {
        return await _context.EventTypes.ToListAsync();
    }

    // GET: api/eventtypes/1
    [HttpGet("{id}")]
    public async Task<ActionResult<EventType>> GetEventType(int id)
    {
        var eventType = await _context.EventTypes.FindAsync(id);

        if (eventType == null)
        {
            return NotFound();
        }

        return eventType;
    }

    // POST: api/eventtypes
    [HttpPost]
    public async Task<ActionResult<EventType>> CreateEventType(CreateEventTypeDto dto)
    {
        var eventType = new EventType
        {
            Name = dto.Name
        };

        _context.EventTypes.Add(eventType);
        await _context.SaveChangesAsync();

        return CreatedAtAction(
            nameof(GetEventType),
            new { id = eventType.EventTypeId },
            eventType);
    }

    // DELETE: api/eventtypes/1
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteEventType(int id)
    {
        var eventType = await _context.EventTypes.FindAsync(id);

        if (eventType == null)
        {
            return NotFound();
        }

        _context.EventTypes.Remove(eventType);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}