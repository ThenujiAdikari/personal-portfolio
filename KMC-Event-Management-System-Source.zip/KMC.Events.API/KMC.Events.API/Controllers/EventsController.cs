﻿using KMC.Events.API.Data;
using KMC.Events.API.DTOs;
using KMC.Events.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KMC.Events.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class EventsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public EventsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: api/events
    [HttpGet]
    public async Task<ActionResult<IEnumerable<object>>> GetEvents()
    {
        var events = await _context.Events
            .Select(e => new
            {
                e.EventId,
                e.Title,
                e.Description,
                e.EventDate,
                e.Location,
                e.EventTypeId,
                e.OrganizerId
            })
            .ToListAsync();

        return Ok(events);
    }

    // GET: api/events/1
    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetEvent(int id)
    {
        var eventItem = await _context.Events
            .Where(e => e.EventId == id)
            .Select(e => new
            {
                e.EventId,
                e.Title,
                e.Description,
                e.EventDate,
                e.Location,
                e.EventTypeId,
                e.OrganizerId
            })
            .FirstOrDefaultAsync();

        if (eventItem == null)
        {
            return NotFound();
        }

        return Ok(eventItem);
    }

    // POST: api/events
    [HttpPost]
    public async Task<ActionResult<Event>> CreateEvent(
        CreateEventDto dto)
    {
        var eventTypeExists = await _context.EventTypes
            .AnyAsync(et =>
                et.EventTypeId == dto.EventTypeId);

        if (!eventTypeExists)
        {
            return BadRequest("Invalid EventTypeId.");
        }

        var organizerExists = await _context.Users
            .AnyAsync(u =>
                u.UserId == dto.OrganizerId);

        if (!organizerExists)
        {
            return BadRequest("Invalid OrganizerId.");
        }

        var eventItem = new Event
        {
            Title = dto.Title,
            Description = dto.Description,
            EventDate = dto.EventDate,
            Location = dto.Location,
            EventTypeId = dto.EventTypeId,
            OrganizerId = dto.OrganizerId
        };

        _context.Events.Add(eventItem);

        await _context.SaveChangesAsync();

        return CreatedAtAction(
            nameof(GetEvent),
            new { id = eventItem.EventId },
            eventItem);
    }

    // PUT: api/events/1
    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateEvent(
        int id,
        CreateEventDto dto)
    {
        var eventItem = await _context.Events
            .FindAsync(id);

        if (eventItem == null)
        {
            return NotFound();
        }

        // Only the event creator can update it
        if (eventItem.OrganizerId != dto.OrganizerId)
        {
            return Forbid();
        }

        var eventTypeExists = await _context.EventTypes
            .AnyAsync(et =>
                et.EventTypeId == dto.EventTypeId);

        if (!eventTypeExists)
        {
            return BadRequest("Invalid EventTypeId.");
        }

        eventItem.Title = dto.Title;
        eventItem.Description = dto.Description;
        eventItem.EventDate = dto.EventDate;
        eventItem.Location = dto.Location;
        eventItem.EventTypeId = dto.EventTypeId;

        await _context.SaveChangesAsync();

        return NoContent();
    }

    // DELETE: api/events/1
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteEvent(int id)
    {
        var eventItem = await _context.Events
            .FindAsync(id);

        if (eventItem == null)
        {
            return NotFound();
        }

        _context.Events.Remove(eventItem);

        await _context.SaveChangesAsync();

        return NoContent();
    }
}