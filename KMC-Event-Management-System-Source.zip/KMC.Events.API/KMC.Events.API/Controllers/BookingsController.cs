﻿using KMC.Events.API.Data;
using KMC.Events.API.DTOs;
using KMC.Events.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KMC.Events.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class BookingsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public BookingsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: api/bookings
    [HttpGet]
    public async Task<ActionResult<IEnumerable<object>>> GetBookings()
    {
        var bookings = await _context.Bookings
            .Select(b => new
            {
                b.BookingId,
                b.UserId,
                UserName = b.User.FullName,

                b.EventId,
                EventTitle = b.Event.Title,

                b.NumberOfTickets,
                b.BookingDate,
                b.Status
            })
            .ToListAsync();

        return Ok(bookings);
    }
    // GET: api/bookings/5
    [HttpGet("{id}")]
    public async Task<ActionResult<object>> GetBooking(int id)
    {
        var booking = await _context.Bookings
            .Where(b => b.BookingId == id)
            .Select(b => new
            {
                b.BookingId,
                b.UserId,
                b.EventId,
                b.NumberOfTickets,
                b.BookingDate,
                b.Status
            })
            .FirstOrDefaultAsync();

        if (booking == null)
        {
            return NotFound();
        }

        return Ok(booking);
    }

    // POST: api/bookings
    [HttpPost]
    public async Task<ActionResult<Booking>> CreateBooking(
        CreateBookingDto dto)
    {
        var userExists = await _context.Users
            .AnyAsync(u => u.UserId == dto.UserId);

        var eventExists = await _context.Events
            .AnyAsync(e => e.EventId == dto.EventId);

        if (!userExists || !eventExists)
        {
            return BadRequest("Invalid UserId or EventId.");
        }

        var booking = new Booking
        {
            UserId = dto.UserId,
            EventId = dto.EventId,
            NumberOfTickets = dto.NumberOfTickets,
            BookingDate = DateTime.Now,
            Status = "Booked"
        };

        _context.Bookings.Add(booking);
        await _context.SaveChangesAsync();

        return CreatedAtAction(
            nameof(GetBooking),
            new { id = booking.BookingId },
            booking);
    }
    // PUT: api/bookings/5/cancel
    [HttpPut("{id}/cancel")]
    public async Task<IActionResult> CancelBooking(int id)
    {
        var booking = await _context.Bookings.FindAsync(id);

        if (booking == null)
        {
            return NotFound();
        }

        if (booking.Status == "Cancelled")
        {
            return BadRequest("Booking is already cancelled.");
        }

        booking.Status = "Cancelled";

        await _context.SaveChangesAsync();

        return Ok(new
        {
            message = "Booking cancelled successfully."
        });
    }
}