﻿using KMC.Events.API.Data;
using KMC.Events.API.DTOs;
using KMC.Events.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KMC.Events.API.Controllers;

[Route("api/[controller]")]
[ApiController]
public class RegistrationsController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public RegistrationsController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: api/registrations
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Registration>>> GetRegistrations()
    {
        var registrations = await _context.Registrations
            .Include(r => r.Event)
            .Include(r => r.Participant)
            .ToListAsync();

        return registrations;
    }

    // GET: api/registrations/1
    [HttpGet("{id}")]
    public async Task<ActionResult<Registration>> GetRegistration(int id)
    {
        var registration = await _context.Registrations
            .Include(r => r.Event)
            .Include(r => r.Participant)
            .FirstOrDefaultAsync(r => r.RegistrationId == id);

        if (registration == null)
        {
            return NotFound();
        }

        return registration;
    }

    // POST: api/registrations
    [HttpPost]
    public async Task<ActionResult<Registration>> CreateRegistration(
        CreateRegistrationDto dto)
    {
        var eventExists = await _context.Events
            .AnyAsync(e => e.EventId == dto.EventId);

        if (!eventExists)
        {
            return BadRequest("Invalid EventId.");
        }

        var participantExists = await _context.Users
            .AnyAsync(u => u.UserId == dto.ParticipantId);

        if (!participantExists)
        {
            return BadRequest("Invalid ParticipantId.");
        }

        var registration = new Registration
        {
            EventId = dto.EventId,
            ParticipantId = dto.ParticipantId
        };

        _context.Registrations.Add(registration);
        await _context.SaveChangesAsync();

        return CreatedAtAction(
            nameof(GetRegistration),
            new { id = registration.RegistrationId },
            registration);
    }

    // DELETE: api/registrations/1
    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteRegistration(int id)
    {
        var registration = await _context.Registrations.FindAsync(id);

        if (registration == null)
        {
            return NotFound();
        }

        _context.Registrations.Remove(registration);
        await _context.SaveChangesAsync();

        return NoContent();
    }
}