﻿namespace KMC.Events.API.DTOs;

public class CreateEventDto
{
    public string Title { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public DateTime EventDate { get; set; }

    public string Location { get; set; } = string.Empty;

    public int EventTypeId { get; set; }

    public int OrganizerId { get; set; }
}