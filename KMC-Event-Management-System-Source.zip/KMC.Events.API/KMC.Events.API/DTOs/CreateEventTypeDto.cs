﻿namespace KMC.Events.API.DTOs;

public class CreateEventTypeDto
{
    public string Name { get; set; } = string.Empty;
}