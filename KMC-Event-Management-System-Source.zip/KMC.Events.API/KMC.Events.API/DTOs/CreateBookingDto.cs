﻿namespace KMC.Events.API.DTOs
{
    public class CreateBookingDto
    {
        public int UserId { get; set; }

        public int EventId { get; set; }

        public int NumberOfTickets { get; set; }
    }
}