﻿namespace KMC.Events.API.DTOs;

public class CreateRegistrationDto
{
    public int EventId { get; set; }

    public int ParticipantId { get; set; }
}