﻿namespace KMC.Events.API.Models
{
    public class EventType
    {
      
        public int EventTypeId { get; set; }

        public string Name { get; set; } = string.Empty;

        public List<Event> Events { get; set; } = new();
    }
}

