﻿namespace KMC.Events.API.Models
{
    public class User
    {
        public int UserId { get; set; }

        public string FullName { get; set; } = string.Empty;

        public string Email { get; set; } = string.Empty;

        public string PasswordHash { get; set; } = string.Empty;

        public string Role { get; set; } = string.Empty;

        public List<Event> Events { get; set; } = new();

        public List<Registration> Registrations { get; set; } = new();
    }
}
