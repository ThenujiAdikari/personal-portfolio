﻿namespace KMC.Events.API.Models;

public class Registration
{
    public int RegistrationId { get; set; }

    // Event relationship
    public int EventId { get; set; }

    public Event? Event { get; set; }

    // Participant relationship
    public int ParticipantId { get; set; }

    public User? Participant { get; set; }

    public DateTime RegistrationDate { get; set; } = DateTime.UtcNow;
}