﻿namespace KMC.Events.API.Models;

public class Booking
{
    public int BookingId { get; set; }

    public int UserId { get; set; }

    public int EventId { get; set; }

    public int NumberOfTickets { get; set; }

    public DateTime BookingDate { get; set; } = DateTime.Now;

    public string Status { get; set; } = "Booked";

    public User? User { get; set; }

    public Event? Event { get; set; }
}