﻿namespace KMC.Events.API.Models;

public class Event
{
    public int EventId { get; set; }

    public string Title { get; set; } = string.Empty;

    public string Description { get; set; } = string.Empty;

    public DateTime EventDate { get; set; }

    public string Location { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    // Event type relationship
    public int EventTypeId { get; set; }

    public EventType? EventType { get; set; }

    // Organizer relationship
    public int OrganizerId { get; set; }

    public User? Organizer { get; set; }

    // Registrations for this event
    public List<Registration> Registrations { get; set; } = new();
}