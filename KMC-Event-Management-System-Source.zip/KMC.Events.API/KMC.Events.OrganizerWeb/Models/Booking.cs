﻿namespace KMC.Events.OrganizerWeb.Models;

public class Booking
{
    public int BookingId { get; set; }

    public int UserId { get; set; }

    public string UserName { get; set; } = string.Empty;

    public int EventId { get; set; }

    public string EventTitle { get; set; } = string.Empty;

    public int NumberOfTickets { get; set; }

    public DateTime BookingDate { get; set; }

    public string Status { get; set; } = string.Empty;
}