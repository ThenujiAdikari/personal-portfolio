using KMC.Events.OrganizerWeb.Models;
using KMC.Events.OrganizerWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages.Clients;

public class IndexModel : PageModel
{
    private readonly ApiService _apiService;

    public IndexModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public List<Client> Clients { get; set; } = new();

    public async Task<IActionResult> OnGetAsync()
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        try
        {
            var clients =
                await _apiService.GetClientsAsync();

            Clients = clients?
                .Where(c =>
                    c.Role.Equals(
                        "User",
                        StringComparison.OrdinalIgnoreCase))
                .OrderBy(c => c.FullName)
                .ToList()
                ?? new List<Client>();
        }
        catch
        {
            Clients = new List<Client>();
        }

        return Page();
    }
}