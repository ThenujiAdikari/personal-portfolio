using KMC.Events.OrganizerWeb.Models;
using KMC.Events.OrganizerWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages.Bookings;

public class IndexModel : PageModel
{
    private readonly ApiService _apiService;

    public IndexModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public List<Booking> Bookings { get; set; } = new();

    public async Task<IActionResult> OnGetAsync()
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        var events =
            await _apiService.GetEventsAsync();

        var bookings =
            await _apiService.GetBookingsAsync();

        var myEventIds =
            events?
                .Where(e => e.OrganizerId == organizerId.Value)
                .Select(e => e.EventId)
                .ToHashSet()
            ?? new HashSet<int>();

        Bookings =
            bookings?
                .Where(b => myEventIds.Contains(b.EventId))
                .OrderByDescending(b => b.BookingDate)
                .ToList()
            ?? new List<Booking>();

        return Page();
    }
}
