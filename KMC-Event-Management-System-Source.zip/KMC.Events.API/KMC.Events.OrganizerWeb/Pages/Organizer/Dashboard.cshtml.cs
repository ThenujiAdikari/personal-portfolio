using KMC.Events.OrganizerWeb.Models;
using KMC.Events.OrganizerWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages.Organizer;

public class DashboardModel : PageModel
{
    private readonly ApiService _apiService;

    public int TotalEvents { get; set; }

    public int TotalBookings { get; set; }

    public int TotalClients { get; set; }

    public int ActiveEvents { get; set; }

    public List<Event> UpcomingEvents { get; set; } = new();

    public DashboardModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task<IActionResult> OnGetAsync()
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        try
        {
            var events =
                await _apiService.GetEventsAsync();

            var bookings =
                await _apiService.GetBookingsAsync();

            var clients =
                await _apiService.GetClientsAsync();


            var myEvents =
                events?
                .Where(e => e.OrganizerId == organizerId.Value)
                .ToList()
                ?? new List<Event>();


            TotalEvents = myEvents.Count;


            ActiveEvents = myEvents.Count(e =>
                e.EventDate.Date >= DateTime.Today);


            UpcomingEvents = myEvents
                .Where(e =>
                    e.EventDate.Date >= DateTime.Today)
                .OrderBy(e => e.EventDate)
                .Take(4)
                .ToList();


            // Only bookings for this organizer's events
            var myEventIds =
                myEvents
                .Select(e => e.EventId)
                .ToHashSet();


            TotalBookings =
                bookings?
                .Count(b =>
                    myEventIds.Contains(b.EventId)
                    &&
                    b.Status != "Cancelled")
                ?? 0;


            // Count normal users only
            TotalClients =
                clients?
                .Count(c =>
                    c.Role.Equals(
                        "User",
                        StringComparison.OrdinalIgnoreCase))
                ?? 0;
        }
        catch
        {
            TotalEvents = 0;
            TotalBookings = 0;
            TotalClients = 0;
            ActiveEvents = 0;

            UpcomingEvents = new List<Event>();
        }

        return Page();
    }
}