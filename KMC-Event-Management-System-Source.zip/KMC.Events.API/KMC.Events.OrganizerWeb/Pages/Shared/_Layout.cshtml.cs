using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages.Shared;

public class _LayoutModel : PageModel
{
}