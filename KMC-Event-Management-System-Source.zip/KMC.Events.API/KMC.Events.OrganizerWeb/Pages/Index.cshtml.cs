using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
