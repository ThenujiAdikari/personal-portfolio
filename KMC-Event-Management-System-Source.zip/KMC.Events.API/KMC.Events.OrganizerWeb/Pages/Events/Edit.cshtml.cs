using KMC.Events.OrganizerWeb.Models;
using KMC.Events.OrganizerWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages.Events;

public class EditModel : PageModel
{
    private readonly ApiService _apiService;

    public EditModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    [BindProperty]
    public Event EventItem { get; set; } = new();

    public List<EventType> EventTypes { get; set; } = new();

    public string? ErrorMessage { get; set; }

    public async Task<IActionResult> OnGetAsync(int id)
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        var eventItem =
            await _apiService.GetEventByIdAsync(id);

        if (eventItem == null)
        {
            return NotFound();
        }

        // Organizer can only edit their own event
        if (eventItem.OrganizerId != organizerId.Value)
        {
            return RedirectToPage("/Events/Index");
        }

        EventItem = eventItem;

        EventTypes =
            await _apiService.GetEventTypesAsync()
            ?? new List<EventType>();

        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        EventTypes =
            await _apiService.GetEventTypesAsync()
            ?? new List<EventType>();

        var originalEvent =
            await _apiService.GetEventByIdAsync(
                EventItem.EventId);

        if (originalEvent == null)
        {
            return NotFound();
        }

        // Ownership protection
        if (originalEvent.OrganizerId != organizerId.Value)
        {
            return RedirectToPage("/Events/Index");
        }

        if (string.IsNullOrWhiteSpace(EventItem.Title) ||
            string.IsNullOrWhiteSpace(EventItem.Description) ||
            string.IsNullOrWhiteSpace(EventItem.Location))
        {
            ErrorMessage =
                "Please complete all event information.";

            return Page();
        }

        EventItem.OrganizerId = organizerId.Value;

        try
        {
            var success =
                await _apiService.UpdateEventAsync(
                    EventItem.EventId,
                    EventItem);

            if (!success)
            {
                ErrorMessage =
                    "Unable to update the event.";

                return Page();
            }

            TempData["Message"] =
                "Event updated successfully.";

            return RedirectToPage("/Events/Index");
        }
        catch (Exception ex)
        {
            ErrorMessage =
                "Unable to update event: " + ex.Message;

            return Page();
        }
    }
}