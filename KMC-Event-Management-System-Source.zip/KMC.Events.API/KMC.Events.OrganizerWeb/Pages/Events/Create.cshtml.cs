using KMC.Events.OrganizerWeb.Models;
using KMC.Events.OrganizerWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages.Events;

public class CreateModel : PageModel
{
    private readonly ApiService _apiService;

    public CreateModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    [BindProperty]
    public Event EventItem { get; set; } = new();

    public List<EventType> EventTypes { get; set; } = new();

    public string? ErrorMessage { get; set; }

    public async Task<IActionResult> OnGetAsync()
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        EventTypes =
            await _apiService.GetEventTypesAsync()
            ?? new List<EventType>();

        EventItem.EventDate = DateTime.Today.AddDays(1);

        return Page();
    }

    public async Task<IActionResult> OnPostAsync()
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        EventTypes =
            await _apiService.GetEventTypesAsync()
            ?? new List<EventType>();

        if (string.IsNullOrWhiteSpace(EventItem.Title) ||
            string.IsNullOrWhiteSpace(EventItem.Description) ||
            string.IsNullOrWhiteSpace(EventItem.Location))
        {
            ErrorMessage =
                "Please complete all event information.";

            return Page();
        }

        if (EventItem.EventDate < DateTime.Today)
        {
            ErrorMessage =
                "Event date cannot be in the past.";

            return Page();
        }

        EventItem.OrganizerId = organizerId.Value;

        try
        {
            var success =
                await _apiService.CreateEventAsync(EventItem);

            if (!success)
            {
                ErrorMessage =
                    "Unable to create the event.";

                return Page();
            }

            TempData["Message"] =
                "Event created successfully.";

            return RedirectToPage("/Events/Index");
        }
        catch (Exception ex)
        {
            ErrorMessage =
                "Unable to create event: " + ex.Message;

            return Page();
        }
    }
}