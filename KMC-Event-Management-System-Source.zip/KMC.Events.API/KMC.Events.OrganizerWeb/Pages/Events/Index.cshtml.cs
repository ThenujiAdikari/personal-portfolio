using KMC.Events.OrganizerWeb.Models;
using KMC.Events.OrganizerWeb.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages.Events;

public class IndexModel : PageModel
{
    private readonly ApiService _apiService;

    public IndexModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public List<Event> Events { get; set; } = new();

    [TempData]
    public string? Message { get; set; }

    public async Task<IActionResult> OnGetAsync()
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        var events = await _apiService.GetEventsAsync();

        if (events != null)
        {
            Events = events
                .Where(e => e.OrganizerId == organizerId.Value)
                .OrderBy(e => e.EventDate)
                .ToList();
        }

        return Page();
    }
    public async Task<IActionResult> OnPostDeleteAsync(int id)
    {
        var organizerId =
            HttpContext.Session.GetInt32("OrganizerId");

        if (organizerId == null)
        {
            return RedirectToPage("/Login");
        }

        var eventItem =
            await _apiService.GetEventByIdAsync(id);

        if (eventItem == null)
        {
            Message = "Event not found.";
            return RedirectToPage();
        }

        // Only the creator can delete the event
        if (eventItem.OrganizerId != organizerId.Value)
        {
            Message = "You are not allowed to delete this event.";
            return RedirectToPage();
        }

        var success =
            await _apiService.DeleteEventAsync(id);

        Message = success
            ? "Event deleted successfully."
            : "Unable to delete the event.";

        return RedirectToPage();
    }
}