using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.OrganizerWeb.Pages;

public class LoginModel : PageModel
{
    [BindProperty]
    public string Email { get; set; } = string.Empty;

    [BindProperty]
    public string Password { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }

    public IActionResult OnGet()
    {
        if (HttpContext.Session.GetInt32("OrganizerId") != null)
        {
            return RedirectToPage(
                "/Organizer/Dashboard");
        }

        return Page();
    }

    public IActionResult OnPost()
    {
        if (string.IsNullOrWhiteSpace(Email) ||
            string.IsNullOrWhiteSpace(Password))
        {
            ErrorMessage =
                "Please enter your email and password.";

            return Page();
        }

        if (Email.Equals(
                "organizer@kmc.lk",
                StringComparison.OrdinalIgnoreCase)
            &&
            Password == "Admin123")
        {
            HttpContext.Session.SetInt32(
                "OrganizerId",
                1);

            HttpContext.Session.SetString(
                "OrganizerName",
                "KMC Organizer");

            HttpContext.Session.SetString(
                "OrganizerRole",
                "Organizer");

            return RedirectToPage(
                "/Organizer/Dashboard");
        }

        ErrorMessage =
            "Invalid organizer email or password.";

        return Page();
    }

    public IActionResult OnGetLogout()
    {
        HttpContext.Session.Clear();

        return RedirectToPage("/Login");
    }
}