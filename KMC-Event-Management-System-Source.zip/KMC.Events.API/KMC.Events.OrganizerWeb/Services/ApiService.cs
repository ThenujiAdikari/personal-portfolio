﻿using System.Net.Http.Json;
using KMC.Events.OrganizerWeb.Models;

namespace KMC.Events.OrganizerWeb.Services;

public class ApiService
{
    private readonly HttpClient _httpClient;

    public ApiService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    // GET ALL EVENTS
    public async Task<List<Event>?> GetEventsAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<Event>>(
            "api/events");
    }

    // GET ONE EVENT
    public async Task<Event?> GetEventByIdAsync(int id)
    {
        return await _httpClient.GetFromJsonAsync<Event>(
            $"api/events/{id}");
    }

    // GET EVENT TYPES
    public async Task<List<EventType>?> GetEventTypesAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<EventType>>(
            "api/eventtypes");
    }

    // CREATE EVENT
    public async Task<bool> CreateEventAsync(Event eventItem)
    {
        var data = new
        {
            title = eventItem.Title,
            description = eventItem.Description,
            eventDate = eventItem.EventDate,
            location = eventItem.Location,
            eventTypeId = eventItem.EventTypeId,
            organizerId = eventItem.OrganizerId
        };

        var response = await _httpClient.PostAsJsonAsync(
            "api/events",
            data);

        return response.IsSuccessStatusCode;
    }

    // UPDATE EVENT
    public async Task<bool> UpdateEventAsync(
        int id,
        Event eventItem)
    {
        var data = new
        {
            title = eventItem.Title,
            description = eventItem.Description,
            eventDate = eventItem.EventDate,
            location = eventItem.Location,
            eventTypeId = eventItem.EventTypeId,
            organizerId = eventItem.OrganizerId
        };

        var response = await _httpClient.PutAsJsonAsync(
            $"api/events/{id}",
            data);

        return response.IsSuccessStatusCode;
    }

    // DELETE EVENT
    public async Task<bool> DeleteEventAsync(int id)
    {
        var response = await _httpClient.DeleteAsync(
            $"api/events/{id}");

        return response.IsSuccessStatusCode;
    }

    // GET USERS
    public async Task<List<User>?> GetUsersAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<User>>(
            "api/users");
    }

    // ORGANIZER LOGIN
    public async Task<User?> LoginAsync(
        string email,
        string password)
    {
        var users = await GetUsersAsync();

        if (users == null)
        {
            return null;
        }

        return users.FirstOrDefault(u =>
            u.Email.Equals(
                email,
                StringComparison.OrdinalIgnoreCase)
            &&
            u.PasswordHash == password
            &&
            u.Role.Equals(
                "Organizer",
                StringComparison.OrdinalIgnoreCase));
    }
    // GET BOOKINGS
    public async Task<List<Booking>?> GetBookingsAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<Booking>>(
            "api/bookings");
    }


    // GET CLIENTS / USERS
    public async Task<List<Client>?> GetClientsAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<Client>>(
            "api/users");
    }
}