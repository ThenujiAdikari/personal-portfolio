﻿using System.Net.Http.Json;
using KMC.Events.Web.Models;

namespace KMC.Events.Web.Services;

public class ApiService
{
    private readonly HttpClient _httpClient;

    public ApiService(HttpClient httpClient)
    {
        _httpClient = httpClient;
    }

    // USERS
    public async Task<List<User>?> GetUsersAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<User>>("api/users");
    }

    public async Task<User?> CreateUserAsync(User user)
    {
        var response = await _httpClient.PostAsJsonAsync("api/users", user);
        response.EnsureSuccessStatusCode();

        return await response.Content.ReadFromJsonAsync<User>();
    }

    // EVENT TYPES
    public async Task<List<EventType>?> GetEventTypesAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<EventType>>("api/eventtypes");
    }

    public async Task<EventType?> CreateEventTypeAsync(EventType eventType)
    {
        var response = await _httpClient.PostAsJsonAsync(
            "api/eventtypes", eventType);

        response.EnsureSuccessStatusCode();

        return await response.Content.ReadFromJsonAsync<EventType>();
    }

    // EVENTS

    public async Task<List<Event>?> GetEventsAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<Event>>("api/events");
    }

    // GET ONE EVENT BY ID
    public async Task<Event?> GetEventByIdAsync(int id)
    {
        return await _httpClient.GetFromJsonAsync<Event>($"api/events/{id}");
    }

    public async Task<Event?> CreateEventAsync(Event eventItem)
    {
        var response = await _httpClient.PostAsJsonAsync(
            "api/events", eventItem);

        response.EnsureSuccessStatusCode();

        return await response.Content.ReadFromJsonAsync<Event>();
    }

    // REGISTRATIONS
    public async Task<List<Registration>?> GetRegistrationsAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<Registration>>(
            "api/registrations");
    }

    public async Task<Registration?> CreateRegistrationAsync(
        Registration registration)
    {
        var response = await _httpClient.PostAsJsonAsync(
            "api/registrations", registration);

        response.EnsureSuccessStatusCode();

        return await response.Content.ReadFromJsonAsync<Registration>();
    }
    // BOOKINGS
    public async Task<List<Booking>?> GetBookingsAsync()
    {
        return await _httpClient.GetFromJsonAsync<List<Booking>>(
            "api/bookings");
    }

    public async Task<Booking?> CreateBookingAsync(Booking booking)
    {
        var response = await _httpClient.PostAsJsonAsync(
            "api/bookings", booking);

        response.EnsureSuccessStatusCode();

        return await response.Content.ReadFromJsonAsync<Booking>();
    }

    // REGISTER USER
    public async Task<User?> RegisterUserAsync(
        string fullName,
        string email,
        string password)
    {
        var data = new
        {
            fullName = fullName,
            email = email,
            password = password,
            role = "User"
        };

        var response = await _httpClient.PostAsJsonAsync(
            "api/users",
            data);

        response.EnsureSuccessStatusCode();

        return await response.Content.ReadFromJsonAsync<User>();
    }


    // LOGIN USER
    public async Task<User?> LoginAsync(
        string email,
        string password)
    {
        var users = await GetUsersAsync();

        if (users == null)
        {
            return null;
        }

        return users.FirstOrDefault(u =>
            u.Email.Equals(
                email,
                StringComparison.OrdinalIgnoreCase)
            &&
            u.PasswordHash == password);
    }


    // CANCEL BOOKING
    public async Task<bool> CancelBookingAsync(int bookingId)
    {
        var response = await _httpClient.PutAsync(
            $"api/bookings/{bookingId}/cancel",
            null);

        return response.IsSuccessStatusCode;
    }
}