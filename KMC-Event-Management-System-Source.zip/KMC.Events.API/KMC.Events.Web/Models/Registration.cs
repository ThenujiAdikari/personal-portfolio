﻿namespace KMC.Events.Web.Models;

public class Registration
{
    public int RegistrationId { get; set; }

    public int EventId { get; set; }

    public int ParticipantId { get; set; }
}