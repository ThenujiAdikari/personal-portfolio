using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }
    }
}
