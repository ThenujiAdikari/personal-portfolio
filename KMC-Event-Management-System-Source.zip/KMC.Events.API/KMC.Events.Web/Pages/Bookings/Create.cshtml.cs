using KMC.Events.Web.Models;
using KMC.Events.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages.Bookings;

public class CreateModel : PageModel
{
    private readonly ApiService _apiService;

    public CreateModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public Event? EventItem { get; set; }

    [BindProperty]
    public int EventId { get; set; }

    [BindProperty]
    public int NumberOfTickets { get; set; } = 1;

    public string? ErrorMessage { get; set; }


    public async Task<IActionResult> OnGetAsync(int eventId)
    {
        var userId =
            HttpContext.Session.GetInt32("UserId");

        if (userId == null)
        {
            return RedirectToPage(
                "/Login",
                new
                {
                    returnUrl =
                        $"/Bookings/Create?eventId={eventId}"
                });
        }

        EventItem =
            await _apiService.GetEventByIdAsync(eventId);

        if (EventItem == null)
        {
            return NotFound();
        }

        EventId = eventId;

        return Page();
    }


    public async Task<IActionResult> OnPostAsync()
    {
        var userId =
            HttpContext.Session.GetInt32("UserId");

        if (userId == null)
        {
            return Redirect("/Login");
        }


        if (NumberOfTickets < 1 ||
            NumberOfTickets > 10)
        {
            ErrorMessage =
                "Please select between 1 and 10 tickets.";

            EventItem =
                await _apiService.GetEventByIdAsync(EventId);

            return Page();
        }


        try
        {
            var booking = new Booking
            {
                UserId = userId.Value,
                EventId = EventId,
                NumberOfTickets = NumberOfTickets
            };


            var createdBooking =
                await _apiService.CreateBookingAsync(
                    booking);


            if (createdBooking == null)
            {
                ErrorMessage =
                    "Booking could not be completed.";

                EventItem =
                    await _apiService.GetEventByIdAsync(
                        EventId);

                return Page();
            }


            // Redirect to My Bookings
            return Redirect("/Bookings");
        }
        catch (Exception ex)
        {
            ErrorMessage =
                "Booking could not be completed: "
                + ex.Message;

            EventItem =
                await _apiService.GetEventByIdAsync(
                    EventId);

            return Page();
        }
    }
}