using KMC.Events.Web.Models;
using KMC.Events.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages.Bookings;

public class IndexModel : PageModel
{
    private readonly ApiService _apiService;

    public List<Booking> Bookings { get; set; } = new();

    [TempData]
    public string? Message { get; set; }

    public IndexModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task<IActionResult> OnGetAsync()
    {
        var userId =
            HttpContext.Session.GetInt32("UserId");

        if (userId == null)
        {
            return RedirectToPage("/Login");
        }

        var bookings =
            await _apiService.GetBookingsAsync();

        if (bookings != null)
        {
            Bookings = bookings
                .Where(b =>
                    b.UserId == userId.Value)
                .OrderByDescending(b =>
                    b.BookingDate)
                .ToList();
        }

        return Page();
    }

    public async Task<IActionResult> OnPostCancelAsync(
        int bookingId)
    {
        var userId =
            HttpContext.Session.GetInt32("UserId");

        if (userId == null)
        {
            return RedirectToPage("/Login");
        }

        var bookings =
            await _apiService.GetBookingsAsync();

        var booking = bookings?
            .FirstOrDefault(b =>
                b.BookingId == bookingId &&
                b.UserId == userId.Value);

        if (booking == null)
        {
            Message = "Booking not found.";
            return RedirectToPage();
        }

        var success =
            await _apiService.CancelBookingAsync(
                bookingId);

        Message = success
            ? "Booking cancelled successfully."
            : "Unable to cancel the booking.";

        return RedirectToPage();
    }
}