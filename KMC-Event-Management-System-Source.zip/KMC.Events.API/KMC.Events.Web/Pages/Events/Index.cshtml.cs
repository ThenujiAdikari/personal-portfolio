using KMC.Events.Web.Models;
using KMC.Events.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages.Events;

public class IndexModel : PageModel
{
    private readonly ApiService _apiService;

    public List<Event> Events { get; set; } = new();

    public List<EventType> EventTypes { get; set; } = new();

    [BindProperty(SupportsGet = true)]
    public string? SearchTerm { get; set; }

    [BindProperty(SupportsGet = true)]
    public int? EventTypeId { get; set; }

    [BindProperty(SupportsGet = true)]
    public DateTime? EventDate { get; set; }

    public IndexModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task OnGetAsync()
    {
        var eventsList = await _apiService.GetEventsAsync();
        var eventTypesList = await _apiService.GetEventTypesAsync();

        Events = eventsList ?? new List<Event>();
        EventTypes = eventTypesList ?? new List<EventType>();

        // SEARCH
        if (!string.IsNullOrWhiteSpace(SearchTerm))
        {
            Events = Events
                .Where(e =>
                    (!string.IsNullOrEmpty(e.Title) &&
                     e.Title.Contains(
                         SearchTerm,
                         StringComparison.OrdinalIgnoreCase))
                    ||
                    (!string.IsNullOrEmpty(e.Description) &&
                     e.Description.Contains(
                         SearchTerm,
                         StringComparison.OrdinalIgnoreCase))
                    ||
                    (!string.IsNullOrEmpty(e.Location) &&
                     e.Location.Contains(
                         SearchTerm,
                         StringComparison.OrdinalIgnoreCase)))
                .ToList();
        }

        // FILTER BY EVENT TYPE
        if (EventTypeId.HasValue)
        {
            Events = Events
                .Where(e => e.EventTypeId == EventTypeId.Value)
                .ToList();
        }

        // FILTER BY DATE
        if (EventDate.HasValue)
        {
            Events = Events
                .Where(e => e.EventDate.Date == EventDate.Value.Date)
                .ToList();
        }

        // SHOW EARLIEST EVENTS FIRST
        Events = Events
            .OrderBy(e => e.EventDate)
            .ToList();
    }
}