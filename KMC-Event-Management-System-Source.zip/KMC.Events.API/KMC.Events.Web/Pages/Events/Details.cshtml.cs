using KMC.Events.Web.Models;
using KMC.Events.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages.Events;

public class DetailsModel : PageModel
{
    private readonly ApiService _apiService;

    public DetailsModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public Event? EventItem { get; set; }

    public async Task<IActionResult> OnGetAsync(int id)
    {
        EventItem = await _apiService.GetEventByIdAsync(id);

        if (EventItem == null)
        {
            return NotFound();
        }

        return Page();
    }
}