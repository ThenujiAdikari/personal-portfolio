using KMC.Events.Web.Models;
using KMC.Events.Web.Services;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages;

public class TestConnectionModel : PageModel
{
    private readonly ApiService _apiService;

    public List<User>? Users { get; set; }

    public string Message { get; set; } = "";

    public TestConnectionModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task OnGetAsync()
    {
        try
        {
            Users = await _apiService.GetUsersAsync();

            Message = "SUCCESS! Website is connected to the API.";
        }
        catch (Exception ex)
        {
            Message = "Connection failed: " + ex.Message;
        }
    }
}