using KMC.Events.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages;

public class LoginModel : PageModel
{
    private readonly ApiService _apiService;

    public LoginModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    [BindProperty]
    public string Email { get; set; } = string.Empty;

    [BindProperty]
    public string Password { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }

    public void OnGet()
    {
        // Already logged in
        if (HttpContext.Session.GetInt32("UserId") != null)
        {
            Response.Redirect("/Events");
        }
    }

    public async Task<IActionResult> OnPostAsync(
        string? returnUrl = null)
    {
        if (string.IsNullOrWhiteSpace(Email) ||
            string.IsNullOrWhiteSpace(Password))
        {
            ErrorMessage = "Please enter your email and password.";
            return Page();
        }

        var user = await _apiService.LoginAsync(
            Email,
            Password);

        if (user == null)
        {
            ErrorMessage = "Invalid email or password.";
            return Page();
        }

        // STORE USER IN SESSION
        HttpContext.Session.SetInt32(
            "UserId",
            user.UserId);

        HttpContext.Session.SetString(
            "UserName",
            user.FullName);

        HttpContext.Session.SetString(
            "UserRole",
            user.Role ?? "User");

        if (!string.IsNullOrWhiteSpace(returnUrl) &&
            Url.IsLocalUrl(returnUrl))
        {
            return LocalRedirect(returnUrl);
        }

        return RedirectToPage("/Events/Index");
    }

    public IActionResult OnGetLogout()
    {
        HttpContext.Session.Clear();

        TempData["LogoutMessage"] =
            "You have been logged out successfully.";

        return RedirectToPage("/Index");
    }
}