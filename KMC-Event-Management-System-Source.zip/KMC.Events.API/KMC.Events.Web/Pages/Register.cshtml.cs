using KMC.Events.Web.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace KMC.Events.Web.Pages;

public class RegisterModel : PageModel
{
    private readonly ApiService _apiService;

    public RegisterModel(ApiService apiService)
    {
        _apiService = apiService;
    }

    [BindProperty]
    public string FullName { get; set; } = string.Empty;

    [BindProperty]
    public string Email { get; set; } = string.Empty;

    [BindProperty]
    public string Password { get; set; } = string.Empty;

    public string? ErrorMessage { get; set; }

    public async Task<IActionResult> OnPostAsync()
    {
        if (string.IsNullOrWhiteSpace(FullName) ||
            string.IsNullOrWhiteSpace(Email) ||
            string.IsNullOrWhiteSpace(Password))
        {
            ErrorMessage = "Please complete all fields.";
            return Page();
        }

        try
        {
            var user = await _apiService.RegisterUserAsync(
                FullName,
                Email,
                Password);

            if (user == null)
            {
                ErrorMessage = "Account could not be created.";
                return Page();
            }

            // Automatically log user in
            HttpContext.Session.SetInt32(
                "UserId",
                user.UserId);

            HttpContext.Session.SetString(
                "UserName",
                user.FullName);

            HttpContext.Session.SetString(
                "UserRole",
                user.Role ?? "User");

            return RedirectToPage("/Events/Index");
        }
        catch
        {
            ErrorMessage = "Registration failed. Please try again.";

            return Page();
        }
    }
}